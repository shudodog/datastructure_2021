#include <cstdlib>
#include "list.h"

// Constructor
list_t::list_t(void) :
    num_elements(0) {
    // Create a sentinel node.
    sentinel = new node_t();
}

// Copy constructor
list_t::list_t(const list_t &m_list) :
    num_elements(0) {
    // Create a sentinel node.
    sentinel = new node_t();
    // Copy data.
    for(node_t *node = m_list.sentinel->next; node != m_list.sentinel; node = node->next) {
        push_back(node->data);
    }
}

// Destructor
list_t::~list_t(void) { clear(); delete sentinel; }

// Get the number of elements in the list.
size_t list_t::size(void) const { return num_elements; }

// Get the first node in the list.
node_t list_t::begin(void) const { return *(sentinel->next); }

// Get the next of last node in the list.
node_t list_t::end(void) const { return *sentinel; }

// Add a new element at the end of list.
void list_t::push_back(const data_t m_data) {
    // Create a new node.
    node_t *node = new node_t(m_data);
    num_elements++;
    // Add the node before the sentinel.
    node->next = sentinel;
    node->prev = sentinel->prev;
    sentinel->prev->next = node;
    sentinel->prev = node;
}

// Remove an element at the given location.
void list_t::erase(node_t m_node) {
    node_t *m_node_ptr = &m_node;
    // In case of empty list, never remove the sentinel node.
    if(m_node_ptr != sentinel) {
        // Remove the node from the list.
        m_node_ptr->prev->next = m_node_ptr->next;
        m_node_ptr->next->prev = m_node_ptr->prev;
        // Delete the disconnected node.
        delete m_node_ptr;
        num_elements--;
    }
}





/*************************
 * EEE2020: Assignment 3 *
 *************************/

// Assign contents to the list, and replace the existing list.
list_t& list_t::operator=(const list_t &m_list) {
    /* Assignment */
    //Remove all elements in the list
    clear();
    //Add elements at the end of empty list in order
    for(node_t *node = m_list.sentinel->next; \
    	node != m_list.sentinel; node = node->next){
    	push_back(node->data);
    }
    return *this;
}

// Remove all elements in the list.
void list_t::clear(void) {
    /* Assignment */
    //Remove all nodes in the list but the sentinel
    node_t *node = sentinel->next;
    while(node != sentinel){
    	node = node->next;
    	delete node->prev;
    }
    //Reset the pointers of sentinel node and number of elements
    node->next = node->prev = node;
    num_elements = 0;
}

// Remove the last element in the list.
void list_t::pop_back() {
    /* Assignment */
    //We do not execute pop_back if num_elements == 0
    if(num_elements){
    //Disconnect the node before the sentinel
    node_t *node = sentinel->prev;
    //Let node->prev->next point to sentinel.
    node->prev->next = sentinel;
    //Make sentinel->prev point to node->prev
    sentinel->prev = node->prev;
    //Delete the disconnected node
    delete node;
    //Update number of elements
    num_elements--;
    }
}

// Add a new element at the beginning of list.
void list_t::push_front(const data_t m_data) {
    /* Assignment */
    //Create a new node and update num_elements
    node_t *node = new node_t(m_data);
    num_elements++;
    //Let next point to sentinel-node
    node->next = sentinel->next;
    //Make prev point to sentienl
    node->prev = sentinel;
    //Let sentinel->next->prev point to the new node
    sentinel->next->prev = node;
    //Make sentinel->next point to the new node
    sentinel->next = node;
    
}

// Remove the first element in the list.
void list_t::pop_front(void) {
    /* Assignment */
    //We do not execute pop_front if num_elements == 0
    if(num_elements){
    //assign node to first element in the list
    node_t *node = sentinel->next;
    //Make sentinel->next point to node->next
    sentinel->next = node->next;
    //Let node->next->prev point to senitnel
    node->next->prev = sentinel;
    //Delete the diconnected node
    delete node;
    //Update num_elements
    num_elements--;
    }
    
}

// Insert a new element at the given location.
void list_t::insert(node_t m_node, const data_t m_data) {
    /* Assignment */
    //Locate the node
    node_t *m_node_ptr = &m_node;
    //Create a new node
    node_t *node = new node_t(m_data);
    //Let next point to m_node_ptr
    node->next = m_node_ptr;
    //Make prev point to m_node_ptr->prev
    node->prev = m_node_ptr->prev;
    //Let m_node_ptr->prev->next point to the new node
    m_node_ptr->prev->next = node;
    //Let m_node_ptr->prev point to the new node
    m_node_ptr->prev = node;
    //Update num_elements
    num_elements++;
}

// Merge two lists. m_list becomes empty.
void list_t::merge(list_t &m_list) {
    /* Assignment */
    //Let sentinel->prev->next point to m_list.sentinel->next
    sentinel->prev->next = m_list.sentinel->next;
    //Make m_list.sentinel->next->prev point to sentinel->prev
    m_list.sentinel->next->prev = sentinel->prev;
    //Let m_list.sentinel->prev->next point to sentinel
    m_list.sentinel->prev->next = sentinel;
    //Make sentinel->prev point to m_list.sentinel->prev
    sentinel->prev = m_list.sentinel->prev;
    //Update num_elements
    num_elements += m_list.num_elements;
    //Reset m_list.sentinel and m_list.number of elements
    m_list.sentinel->next = m_list.sentinel->prev = m_list.sentinel;
    m_list.num_elements = 0;
}

/*********************
 * End of Assignment *
 *********************/

