#include "input.h"
#include "func.h"
#include "list.h"

int main(int argc, char **argv) {
    // Define a linked list.
    list_t list;

    /**************************************
     * TEST YOUR CODE HERE FOR VALIDATION *
     **************************************/
    list.push_back(17);
    list.push_back(8);
    list.push_back(11);
    list.push_front(-82);
    list.push_front(-179);
    list.push_front(-41);
    print(list);

    list.insert(list.begin(), 2);
    list.insert(list.begin()+1, 27);
    list.insert(list.begin()+4, 19);
    list.insert(list.end(), -35);
    list.insert(list.end()-1, -94);
    list.insert(list.end()-3, 101);
    print(list);

    list.pop_back();
    list.pop_back();
    list.pop_front();
    print(list);

    list.erase(list.begin());
    list.erase(list.begin()+2);
    list.erase(list.end()-1);
    list.erase(list.end()-3);
    print(list);

    list_t cp = list;
    print(cp);

    cp.clear();
    list = cp;
    print(list);

    list.push_back(0);
    cp.push_front(57);
    list.insert(list.begin(), 90);
    list.insert(list.end(), -4);
    cp.merge(list);
    print(cp);

    /******************
     * END OF TESTING *   
     ******************/





    /* *************************************************
     * WARNING: DO NOT MODIFY THE CODE BELOW THIS LINE *
     ***************************************************/

    // Proceed?
    if(argc != 2) { return 0; }
    
    // Empty the linked list.
    debug("Test #1: clear()");
    list.clear();
    std::cout << "list:" << std::endl; print(list);

    // Add elements read from the input file to the linked list.
    input_t input(argv[1]);
    debug("Test #2: push_back()");
    for(size_t i = 0; i < input.size(); i++) { list.push_back(input[i]); }
    std::cout << "list:" << std::endl; print(list);

    // Split the list into positive- and negative-number lists.
    list_t plist, nlist;
    debug("Test #3: insert(), erase()");
    split(list, plist, nlist);
    print(list, plist, nlist);

    // Use merge functions to combine the lists.
    debug ("Test #4: merge(), operator=, clear()");
    nlist.merge(list);
    list = nlist;
    nlist.clear();
    list.merge(plist);
    print(list, plist, nlist);

    // Split the list again to positive- and negative-number lists.
    split(list, plist, nlist);

    // Move negative nubmers from nlist to list.
    debug("Test #5: pop_back(), push_front()");
    while(nlist.size()) {
        data_t val = *(--(nlist.end()));
        nlist.pop_back();
        list.push_front(val);
    }
    print(list, plist, nlist);

    // Move positive numbers from plist to list.
    debug("Test #6: pop_front(), push_back()");
    while(plist.size()) {
        data_t val = *(plist.begin());
        plist.pop_front();
        list.push_back(val);
    }
    print(list, plist, nlist);

    return 0;
}

