#ifndef __DATA_H__
#define __DATA_H__

#include <cstdint>

typedef int32_t data_t;

#endif

