#include <cstring>
#include <iostream>
#include "func.h"

// Print the information of list.
void print(const list_t &list) {
    std::cout << "size()=" << list.size() << std::endl;
    std::cout << "list=[ ";
    for(node_t n = list.begin(); n != list.end(); n++) {
        std::cout << *n << " ";
    } std::cout << "]" << std::endl << std::endl;
}

// Print the information of three lists.
void print(const list_t &list, const list_t &plist, const list_t &nlist) {
    std::cout << "list:"  << std::endl; print(list);
    std::cout << "plist:" << std::endl; print(plist);
    std::cout << "nlist:" << std::endl; print(nlist);
}

// Split the list into positive- and negative-number lists.
void split(list_t &list, list_t &plist, list_t &nlist) {
    for(node_t n = list.begin(); n != list.end(); n++) {
        if(!*n) { continue; }
        list_t *lptr = *n < 0 ? &nlist : &plist;
        node_t p;
        // Sort list elements in ascending order.
        for(p = lptr->begin(); ((p != lptr->end()) && (*n > *p)); p++) ;
        lptr->insert(p, *n);
        list.erase(n);
    }
}

// Debug message
void debug(const char* msg) {
    for(unsigned i = 0; i < strlen(msg); i++) { std::cout << '-'; } std::cout << std::endl;
    std::cout << msg << std::endl;
    for(unsigned i = 0; i < strlen(msg); i++) { std::cout << '-'; } std::cout << std::endl;
}

