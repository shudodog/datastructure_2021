#ifndef __LIST_FUNC_H__
#define __LIST_FUNC_H__

#include "list.h"

// Print the information of list.
void print(const list_t &list);

// Print the information of three lists.
void print(const list_t &list, const list_t &plist, const list_t &nlist);

// Split the list into positive- and negative-number lists.
void split(list_t &list, list_t &plist, list_t &nlist);

// Debug message
void debug(const char* msg);

#endif

