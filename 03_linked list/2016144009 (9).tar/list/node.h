#ifndef __NODE_H__
#define __NODE_H__

#include <iostream>
#include "data.h"

class node_t{
friend class list_t;
public:
    // Node constructors
    node_t(void) : next(this), prev(this) { }
    node_t(const data_t &m_data) : next(0), prev(0), data(m_data) { }

    // Dereference operator
    data_t& operator*(void)  { return this_ptr()->data; }
    // Address operator
    node_t* operator&(void)  { return this_ptr(); }
    // Prefix increment operator
    node_t& operator++(void) { return *this = *next; }
    // Prefix decrement operator
    node_t& operator--(void) { return *this = *prev; }
    // Postfix increment operator
    node_t& operator++(int)  { *this = *next; return *prev; }
    // Postfix decrement operator
    node_t& operator--(int)  { *this = *prev; return *next; }
    // Forward operator
    node_t& operator+(int v) { node_t *n = this; while(v--) { n = n->next; } return *n; }
    // Backward operator
    node_t& operator-(int v) { node_t *n = this; while(v--) { n = n->prev; } return *n; }
    // Equal operator
    bool operator==(const node_t &m_node) {
        return (m_node.next == next) && (m_node.prev == prev);
    }
    // Not-equal operator
    bool operator!=(const node_t &m_node) {
        return (m_node.next != next) || (m_node.prev != prev);
    }

private:
    // Get the pointer of this node.
    node_t* this_ptr(void) {
        try{ 
            if(!next || !prev || (*(next->prev) != *this) || (*(prev->next) != *this)) {
                throw "Floating node exception: broken node links";
            }
        } catch(const char *msg) { std::cerr << msg << std::endl; exit(1); }
        return next->prev;
    }

    node_t *next;       // Pointer to the next node
    node_t *prev;       // Pointer to the previous node
    data_t data;        // Node data
};

#endif

