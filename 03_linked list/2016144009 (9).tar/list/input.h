#ifndef __INPUT_H__
#define __INPUT_H__

#include <string>
#include "data.h"

// Input handler
class input_t {
public:
    input_t(std::string m_file_name = "data") : array(0), array_size(0) { read(m_file_name); }
    ~input_t() { delete [] array; }

    size_t size() const { return array_size; }
    data_t& operator[](const size_t m_index) const { return array[m_index]; }

private:
    // Read an input file.
    void read(const std::string m_file_name);

    data_t *array;
    size_t array_size;
};

#endif

