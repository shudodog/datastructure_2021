#ifndef __LIST_H__
#define __LIST_H__

#include "node.h"

class list_t {
public:
    // Constructor
    list_t(void);
    // Copy constructor
    list_t(const list_t &m_list);
    // Destructor
    ~list_t(void);

    // Get the number of elements in the list.
    size_t size(void) const;
    // Get the first node in the list.
    node_t begin(void) const;
    // Get the next of last node in the list.
    node_t end(void) const;
    // Assign contents to the list, and replace the existing list.
    list_t& operator=(const list_t &m_list);
    // Remove all elements in the list.
    void clear(void);
    // Add a new element at the end of list.
    void push_back(const data_t m_data);
    // Remove the last element in the list.
    void pop_back(void);
    // Add a new element at the beginning of list.
    void push_front(const data_t m_data);
    // Remove the first element in the list.
    void pop_front(void);
    // Insert a new element at the given location.
    void insert(node_t m_node, const data_t m_data);
    // Remove an element at the given location.
    void erase(node_t m_node);
    // Merge two lists. m_list becomes empty.
    void merge(list_t &m_list);

private:
    node_t *sentinel;       // Pointer to the sentinel node
    size_t num_elements;    // Number of elements in the list
};

#endif

