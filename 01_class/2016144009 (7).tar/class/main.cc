#include <iostream>
#include "array.h"
#include "func.h"

#define N 30

using namespace std;

int main(void) {
    // Create a class instance, a1.
    array_t a1;

    // Allocate the memory space of a1 for N elements.
    a1.reserve(N);

    // Push back a sequence of Fibonacci numbers into a1.
    for(unsigned i = 0; i < N; i++) {
        a1.push_back(fibonacci(i));
    }

    // Create a class instance, a2, as a copy of a1.
    array_t a2 = a1;

    // Mask out non-prime numbers in a2.
    for(size_t i = 0; i < a2.size(); i++) {
        if(!is_prime(a2[i])) {
            a2[i] = 0;
        }
    }

    // Print the elements of a1 and a2.
    cout << "a1\ta2" << endl << "----------" << endl;
    for(size_t i = 0; i < a1.size(); i++) {
        cout << a1[i] << (a1[i] ? "" : "\b ") << "\t"
             << a2[i] << (a2[i] ? "" : "\b ") << endl;
    }

    return 0;
}

