// Nth Fibonacci number
unsigned fibonacci(unsigned n);

// Is N prime?
bool is_prime(unsigned n);

