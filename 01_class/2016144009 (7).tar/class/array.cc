#include <cstdlib>
#include <new>
#include "array.h"

// Class constructor
array_t::array_t() :
    ptr(0),
    num_elements(0),
    array_size(0) {
    // Nothing to do
}


//copy constructor
array_t::array_t(const array_t &m_array):
	num_elements(m_array.num_elements), array_size(m_array.array_size){
	//Allocate a memory space of the same capacity
	ptr = (data_t*)malloc(array_size*sizeof(data_t));
	//Copy elements from the other class
	for(size_t i = 0; i < num_elements; i++){
		new(&ptr[i]) data_t(m_array.ptr[i]);
	}
}




//class destructor
array_t::~array_t(){
	//Deallocate the array
	free(ptr);
}


// Allocate a memory space for the specified number of elements.
void array_t::reserve(const size_t m_array_size) {
	//Create an array, and let the pointer to m_array size, and array 		size to m_array_size  
	ptr = (data_t*)malloc(m_array_size*sizeof(data_t));
	array_size = m_array_size;

}

// Add a new element at the end of array.
void array_t::push_back(const data_t m_value) {
	//Add a new element, m_value, at the end of array
	new (&ptr[num_elements++]) data_t(m_value);

}

