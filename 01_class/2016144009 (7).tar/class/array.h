#ifndef __ARRAY_H__
#define __ARRAY_H__

typedef unsigned data_t;        // data_t represents unsigned int.

class array_t {
public:
    // Class constructor
    array_t();


    //Class copy constructor
    array_t(const array_t &copy);
    
    //Class destructor
    ~array_t();


    // Allocate a memory space for the specified number of elements.
    void reserve(const size_t m_array_size);
    // Add a new element at the end of array.
    void push_back(const data_t m_value);
    // Reference operator
    data_t& operator[](const size_t m_index) const { return ptr[m_index]; }
    // Return the number of elements in the array.
    size_t size() const { return num_elements; }
    // Return the size of allocated memory space.
    size_t capacity() const { return array_size; }

private:
    data_t *ptr;                // Pointer to an array
    size_t num_elements;        // Actual number of elements in the array
    size_t array_size;          // Allocated size of array
};

#endif

