#include "func.h"

// Nth Fibonacci number
unsigned fibonacci(unsigned n) {
    unsigned f1 = 0, f2 = 1, fib = 1;
    for(unsigned i = 0; i < n; i++) { fib = f1 + f2; f1 = f2; f2 = fib; }
    return fib;
}

// Is N prime?
bool is_prime(unsigned n) {
    if(n < 2) { return false; }
    if(n % 2 == 0) { return (n == 2); }
    for(unsigned p = 3; p < n; p += 2) { if(n % p == 0) { return false; } }
    return true;
}

