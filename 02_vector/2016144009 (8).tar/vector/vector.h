#ifndef __VECTOR_H__
#define __VECTOR_H__

#include "data.h"

class vector_t {
public:
    vector_t(void);
    vector_t(const vector_t &m_vector);
    ~vector_t(void);

    // Get the number of elements in the array.
    size_t size(void) const;
    // Get the allocated array size.
    size_t capacity(void) const;
    // Get a pointer to the first element in the array.
    data_t* begin(void) const;
    // Get a pointer to the next of last element.
    data_t* end(void) const;
    // Get a reference of element at the given index.
    data_t& operator[](const size_t m_index) const;
    // Assign new contents to the vector, and replace the existing array (if applicable).
    vector_t& operator=(const vector_t &m_vector);
    // Allocate a memory space of the given size, if it greater than the current size.
    void reserve(const size_t m_array_size);
    // Remove all elements, but keep the array.
    void clear(void);
    // Add a new element at the end of array.
    void push_back(const data_t m_data);
    // Remove the last element in the array.
    void pop_back(void);
    // Insert a new element at the given location.
    void insert(data_t *m_ptr, const data_t m_data);
    // Remove an element at the given location.
    void erase(data_t *m_ptr);

private:
    data_t *array;          // Pointer to an array
    size_t array_size;      // Allocated array size
    size_t num_elements;    // Number of elements in the array
};

#endif

