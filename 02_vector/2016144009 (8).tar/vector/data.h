#ifndef __DATA_H__
#define __DATA_H__

typedef unsigned data_t;

#endif

