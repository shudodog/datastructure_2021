#include <cstdlib>
#include <new>
#include "vector.h"

// Constructor
vector_t::vector_t(void) :
    array(0),
    array_size(0),
    num_elements(0) {
    // Nothing to do
}

// Copy constructor
vector_t::vector_t(const vector_t &m_vector) :
    array_size(m_vector.num_elements),
    num_elements(m_vector.num_elements) {
    // The array is a tight fit.
    array = (data_t*)malloc(sizeof(data_t) * array_size);
    // Copy data.
    for(size_t i = 0; i < num_elements; i++) { new (&array[i]) data_t(m_vector.array[i]); }
}

// Destructor
vector_t::~vector_t() {
    // Destruct all data.
    for(size_t i = 0; i < num_elements; i++) { array[i].~data_t(); }
    // Deallocate the array.
    free(array);
}

// Get the number of elements in the array.
size_t vector_t::size(void) const { return num_elements; }

// Get the allocated array size.
size_t vector_t::capacity(void) const { return array_size; }

// Get a pointer to the first element in the array.
data_t* vector_t::begin(void) const { return array; }

// Get a pointer to the next of last element.
data_t* vector_t::end(void) const { return array + num_elements; }

// Get a reference of element at the given index.
data_t& vector_t::operator[](const size_t m_index) const { return array[m_index]; }

// Assign new contents to the vector, and replace the existing array (if applicable).
vector_t& vector_t::operator=(const vector_t &m_vector) {
    if(&m_vector != this) {
        // Destruct all existing data elements.
        for(size_t i = 0; i < num_elements; i++) { array[i].~data_t(); }
        // Resize the array if the new array is bigger than the current one.
        if(array_size < m_vector.num_elements) {
            free(array);
            // The new array is a tight fit.
            array_size = m_vector.num_elements;
            array = (data_t*)malloc(sizeof(data_t) * array_size);
        }
        // Copy data.
        num_elements = m_vector.num_elements;
        for(size_t i = 0; i < num_elements; i++) { new (&array[i]) data_t(m_vector.array[i]); }
    }
    return *this;
}





/*************************
 * EEE2020: Assignment 2 *
 *************************/

// Allocate a memory space of the given size, if it is greater than the current size.
void vector_t::reserve(const size_t m_array_size) {
    /* Assignment */
    //Allocate a new memory space, 
    //check if the requested size is greater than the current array size
    if (m_array_size > array_size){
    	data_t *array_temp = (data_t*)malloc(sizeof(data_t)*m_array_size);
    	//if there is num_elements in current array, copy data from the old array to the new one
    	if(num_elements){
    		for(size_t i = 0; i < num_elements; i++){
    			array_temp[i] = array[i];
    		}
    		
    	}
    	//deallocate the array
    	free(array);
    	//change to new array
    	array = array_temp;
    	//change to new size
    	array_size = m_array_size;
    	
    }
    
    	
}

// Remove all elements, but keep the array.
void vector_t::clear(void) {
    /* Assignment */
    //Destruct all the existing data in the array
    for(size_t i = 0; i < num_elements; i++){
    	array[i].~data_t();
    }
    //change the num_elements to zero
    num_elements = 0;
}

// Add a new element at the end of array.
void vector_t::push_back(const data_t m_data) {
    /* Assignment */
    //if no array has been previously allocated, an one-element array is created to store the new element
    if(array_size == 0){reserve(1) ; }
    //if the array is full before adding the new element, the array size should double up, so we call reserve function to handle resizing the array
    if(num_elements == array_size){ reserve(array_size ? 2*array_size : 1); }
    //adds a new data element at the end of array
    new(&array[num_elements++]) data_t(m_data);
}

// Remove the last element in the array.
void vector_t::pop_back(void) {
    /* Assignment */
    //removes the last element in the array, array size does not shrink but num_elements shrink after pop_back
    if(num_elements) {array[--num_elements].~data_t(); }
}

// Insert a new element at the given location.
void vector_t::insert(data_t *m_ptr, const data_t m_data) {
    /* Assignment */
    //we know the memory location pointed by m_ptr, so we can know its index by - begin()
    size_t index = m_ptr - begin();
    //if the array is full before insertion, if first needs to double up
    if(num_elements == array_size){ reserve(array_size ? 2*array_size : 1); }
    //shift all subsequent elements using index
    for(size_t n = num_elements; n > index; n--){
    	array[n] = array[n-1];
    }
    //insert m_data to certain index
    array[index] = m_data;
    //num_elements updated
    num_elements++;	
    
}

// Remove an element at the given location.
void vector_t::erase(data_t *m_ptr) {
    /* Assignment */
    //same as insert, we know the memory location pointed by m_ptr, so we can know its index by - begin()
    size_t index = m_ptr - begin();
    //shift all subsequent elements
    for(size_t n = index+1; n < num_elements; n++){
    	array[n-1] = array[n];
    }
    //num_elements updated
    num_elements--;
}

/*********************
 * End of Assignment *
 *********************/

