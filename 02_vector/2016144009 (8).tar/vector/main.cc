#include <iostream>
#include "vector.h"

using namespace std;

// Print the information of vector_t.
void print(const vector_t &m_vector) {
    cout << "capacity=" << m_vector.capacity()  << endl
         << "size="     << m_vector.size()      << endl
         << "array=[ ";
    for(size_t i = 0; i < m_vector.size(); i++) {
        cout << m_vector[i] << " ";
    }
    cout << "]"                         << endl << endl;
}

int main(void) {
    // Create a vector_t variable named vec.
    vector_t vec;

    // Test push_back().
    vec.push_back(17);
    vec.push_back(8);
    vec.push_back(11);
    vec.push_back(82);
    vec.push_back(179);
    vec.push_back(41);
    print(vec);

    // Test insert().
    vec.insert(vec.begin(), 2);
    vec.insert(vec.begin()+1, 27);
    vec.insert(vec.begin()+4, 19);
    vec.insert(vec.end(), 35);
    vec.insert(vec.end()-1, 94);
    vec.insert(vec.end()-3, 101);
    print(vec);

    // Test pop_back().
    vec.pop_back();
    vec.pop_back();
    vec.pop_back();
    print(vec);

    // Test erase().
    vec.erase(vec.begin());
    vec.erase(vec.begin()+2);
    vec.erase(vec.end()-1);
    vec.erase(vec.end()-3);
    print(vec);

    // Create a vector_t variable named cp as a copy of vec.
    vector_t cp = vec;
    print(cp);

    // Test clear() and assignment operator.
    cp.clear();
    vec = cp;
    print(vec);

    // Test reserve(), push_back(), insert(), and assignment operator.
    cp.reserve(10);
    vec.push_back(57);
    vec.insert(vec.begin()+1, 90);
    vec.insert(vec.end()-2, 4);
    cp = vec;
    print(cp);

    return 0;
}

