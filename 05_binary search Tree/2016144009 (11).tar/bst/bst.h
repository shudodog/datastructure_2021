#ifndef __BST_H__
#define __BST_H__

#include "tree.h"

// Binary search tree (BST) based on the binary tree base class
class bst_t : public tree_t {
public:
    bst_t(void);
    ~bst_t(void);

    // Add a new element to the tree.
    void insert(const data_t &m_data);
    // Remove the element in the tree if it has one.
    void remove(const data_t &m_data);

/*************************
 * EEE2020: Assignment 5 *
 *************************/
private:
    //Add a new element to the subtree
    node_t* insert(const data_t &m_data, node_t *m_node);
    //Remove the element in the subtree if it has one
    node_t* remove(const data_t &m_data, node_t *m_node);


/*********************
 * End of Assignment *
 *********************/
};

#endif

