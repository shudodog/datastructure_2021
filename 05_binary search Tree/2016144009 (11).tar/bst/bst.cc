#include <cstdlib>
#include <new>
#include "bst.h"


/*************************
 * EEE2020: Assignment 5 *
 *************************/

// Add a new element to the tree.
void bst_t::insert(const data_t &m_data) {
    /* Assignment */
    //Public insert function
    root = insert(m_data, root);
}
//Private insert function
node_t* bst_t::insert(const data_t &m_data, node_t *m_node) {
    //if there's no m_node, insert new node and update num_elements
    if(!m_node) { num_elements++; m_node = new node_t(m_data); }
    //if m_node->data is bigger than m_data, m_node->left is insert(m_data,m_node->left)
    else if(m_data < m_node->data) { m_node->left = insert(m_data, m_node->left); }
    //if m_node->data is smaller than m_data, m_node->right is insert(m_data,m_node->left)
    else if(m_node->data < m_data) { m_node->right = insert(m_data, m_node->right); }
    return m_node;
}
// Remove the element in the tree if it has one.
void bst_t::remove(const data_t &m_data) {
    /* Assignment */
    //Public remove fucntion
    root = remove(m_data, root);
}
//Private remove function
node_t* bst_t::remove(const data_t &m_data, node_t *m_node) {
    if(m_node) { 
    //Recursivley remove the node down the hierarchy
    	if(m_data < m_node->data) { m_node->left = remove(m_data, m_node->left); }
    	else if(m_node->data < m_data) { m_node->right = remove(m_data, m_node->right); }
    	//Not a left or right. This node has the data
    	else if(!m_node->left || !m_node->right) { //One or no child
    	    node_t *node = m_node;
    	    m_node = m_node->left ? m_node->left : m_node->right;
    	    delete node;
    	    num_elements--;
    	}
    	else{ // Two children
    	//data right_min is find_min(m_node->right)
    	    const data_t &right_min = find_min(m_node->right);
    	    //delete m_node' data
    	    m_node->data.~data_t();
    	    //insert right_min to m_node->data
    	    new (&m_node->data) data_t(right_min);
    	    //remove m_node->right
    	    m_node->right = remove(right_min, m_node->right);
    	    }
    	} // m_node == 0means end of tree. Data not found
    	return m_node;
}

/*********************
 * End of Assignment *
 *********************/





// Constructor
bst_t::bst_t(void) { /* Nothing to do */ }

// Destructor
bst_t::~bst_t(void) { /* Nothing to do */ }

