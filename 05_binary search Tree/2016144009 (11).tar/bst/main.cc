#include <iostream>
#include "input.h"
#include "bst.h"

using namespace std;

// Print the information of BST
void print(bst_t &bst) {
    cout << "height() = "   << bst.height()   << endl;
    cout << "size() = "     << bst.size()     << endl;
    if(bst.size()) {
        cout << "find_min() = " << bst.find_min() << endl;
        cout << "find_max() = " << bst.find_max() << endl;
    }
#ifdef DEBUG
    cout << "nodes: "       << endl; bst.print();
#endif
    cout << endl;
}

int main(int argc, char **argv) {
    // Define a BST.
    bst_t bst;

    /**************************************
     * TEST YOUR CODE HERE FOR VALIDATION *
     **************************************/
    bst.insert(45);
    bst.insert(23);
    bst.insert(71);
    bst.insert(34);
    bst.insert(55);
    bst.insert(10);
    bst.insert(83);
    bst.insert(7);
    bst.insert(30);
    bst.insert(64);
    bst.insert(15);
    bst.insert(95);
    bst.insert(39);
    bst.insert(77);
    bst.insert(37);
    bst.insert(41);
    bst.insert(80);
    bst.insert(59);
    bst.insert(2);
    print(bst);

    bst.remove(59);
    bst.remove(55);
    bst.remove(71);
    bst.remove(15);
    bst.remove(95);
    bst.remove(2);
    print(bst);
    /******************
     * END OF TESTING *   
     ******************/





    /* *************************************************
     * WARNING: DO NOT MODIFY THE CODE BELOW THIS LINE *
     ***************************************************/

    // Proceed?
    if(argc != 2) { return 0; }
    
    // Empty the BST.
    cout << "----------------" << endl
         << "Test #1: clear()" << endl
         << "----------------" << endl;
    bst.clear();
    print(bst);


    // Add elements read from the input file to the BST.
    cout << "-----------------" << endl
         << "Test #2: insert()" << endl
         << "-----------------" << endl;
    input_t input(argv[1]);
    for(size_t i = 0; i < input.size(); i++) { bst.insert(input[i]); }
    print(bst);


    // Check if certain elements are contained in the BST.
    cout << "-------------------" << endl
         << "Test #3: contains()" << endl
         << "-------------------" << endl;
    data_t d;
    cout << "contains(" << (d = 497)  << ") = " << (bst.contains(d) ? "yes" : "no") << endl;
    cout << "contains(" << (d =  24)  << ") = " << (bst.contains(d) ? "yes" : "no") << endl;
    cout << "contains(" << (d = 169)  << ") = " << (bst.contains(d) ? "yes" : "no") << endl;
    cout << "contains(" << (d =  15)  << ") = " << (bst.contains(d) ? "yes" : "no") << endl;
    cout << "contains(" << (d = 275)  << ") = " << (bst.contains(d) ? "yes" : "no") << endl;
    cout << "contains(" << (d = 387)  << ") = " << (bst.contains(d) ? "yes" : "no") << endl;
    cout << "contains(" << (d =   9)  << ") = " << (bst.contains(d) ? "yes" : "no") << endl;
    cout << "contains(" << (d = 400)  << ") = " << (bst.contains(d) ? "yes" : "no") << endl;
    cout << "contains(" << (d = 251)  << ") = " << (bst.contains(d) ? "yes" : "no") << endl;
    cout << endl;


    // Remove elements in the BST.
    cout << "-----------------" << endl
         << "Test #4: remove()" << endl
         << "-----------------" << endl;
    bst.remove(497);
    bst.remove(24);
    bst.remove(169);
    bst.remove(15);
    bst.remove(275);
    bst.remove(387);
    bst.remove(9);
    bst.remove(400);
    bst.remove(251);
    print(bst);


    // Repeat all functions once again.
    cout << "------------------------------------" << endl
         << "Test #5: clear(), insert(), remove()" << endl
         << "------------------------------------" << endl;
    bst.clear();
    for(size_t i = input.size(); i > 0; i--) { bst.insert(input[i-1]); }
    bst.remove(322);
    bst.remove(340);
    bst.remove(203);
    print(bst);


    return 0;
}

