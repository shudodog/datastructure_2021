#include <iostream>
#include "input.h"
#include "splay.h"

using namespace std;

// Print the information of splay tree.
void print(splay_t &splay) {
    cout << "height() = "       << splay.height()   << endl;
    cout << "size() = "         << splay.size()     << endl;
    if(splay.size()) {
        cout << "find_min() = " << splay.find_min() << endl;
        cout << "find_max() = " << splay.find_max() << endl;
    }
#ifdef DEBUG
    cout << "nodes: "           << endl; splay.print();
#endif
    cout << endl;
}

int main(int argc, char **argv) {
    // Define a splay tree.
    splay_t splay;

    /**************************************
     * TEST YOUR CODE HERE FOR VALIDATION *
     **************************************/
    splay.insert(1);
    splay.insert(3);
    splay.insert(3);
    splay.insert(5);
    splay.insert(7);
    splay.insert(9);
    print(splay);

    splay.contains(1);
    splay.contains(9);
    splay.contains(3);
    splay.contains(1);
    splay.contains(9);
    print(splay);

    splay.remove(7);
    print(splay);
    /******************
     * END OF TESTING *   
     ******************/





    /* *************************************************
     * WARNING: DO NOT MODIFY THE CODE BELOW THIS LINE *
     ***************************************************/

    // Proceed?
    if(argc != 2) { return 0; }
    
    // Empty the splay tree.
    cout << "----------------" << endl
         << "Test #1: clear()" << endl
         << "----------------" << endl;
    splay.clear();
    print(splay);


    // Add elements read from the input file to the splay tree.
    cout << "-----------------" << endl
         << "Test #2: insert()" << endl
         << "-----------------" << endl;
    input_t input(argv[1]);
    for(size_t i = 0; i < input.size(); i++) { splay.insert(input[i]); }
    print(splay);


    // Check if certain elements are contained in the splay tree.
    cout << "-------------------" << endl
         << "Test #3: contains()" << endl
         << "-------------------" << endl;
    data_t d = splay.find_min();
    cout << "contains(" << (d = splay.find_min()) << ") = "
         << (splay.contains(d) ? "yes" : "no")    << endl;
    cout << "contains(" << (d = splay.find_max()) << ") = "
         << (splay.contains(d) ? "yes" : "no")    << endl;
    cout << "contains(" << (d = 125)              << ") = "
         << (splay.contains(d) ? "yes" : "no")    << endl;
    cout << "contains(" << (d = 375)              << ") = "
         << (splay.contains(d) ? "yes" : "no")    << endl;
    cout << "contains(" << (d = 250)              << ") = "
         << (splay.contains(d) ? "yes" : "no")    << endl;
    cout << endl;
    print(splay);


    // Remove elements in the splay tree.
    cout << "-----------------" << endl
         << "Test #4: remove()" << endl
         << "-----------------" << endl;
    splay.remove(splay.find_min());
    splay.remove(splay.find_max());
    splay.remove(125);
    splay.remove(375);
    splay.remove(250);
    print(splay);


    // Repeat all functions once again.
    cout << "------------------------------------" << endl
         << "Test #5: clear(), insert(), remove()" << endl
         << "------------------------------------" << endl;
    splay.clear();
    for(size_t i = input.size(); i > 0; i--) { splay.insert(input[i-1]); }
    splay.remove(104);
    splay.remove(175);
    splay.remove(456);
    splay.remove(25);
    splay.remove(275);
    splay.remove(53);
    splay.remove(400);
    print(splay);


    return 0;
}

