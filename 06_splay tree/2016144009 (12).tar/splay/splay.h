#ifndef __SPLAY_H__
#define __SPLAY_H__

#include "tree.h"

// Splay tree based on the binary tree base class
class splay_t : public tree_t {
public:
    splay_t(void);
    ~splay_t(void);

    // Return true if the tree contains the data.
    bool contains(const data_t &m_data);
    // Add a new element to the tree.
    void insert(const data_t &m_data);
    // Remove the element in the tree if it has one.
    void remove(const data_t &m_data);

/*************************
 * EEE2020: Assignment 6 *
 *************************/
 
private:
    // Splay the subtree.
    node_t* splay(const data_t &m_data, node_t *m_node);
    // Rotate the subtree with the left child.
    node_t* rotate_with_left(node_t *m_node);
    //Rotate the subtree with the right child.
    node_t* rotate_with_right(node_t *m_node);
    



/*********************
 * End of Assignment *
 *********************/
};

#endif

