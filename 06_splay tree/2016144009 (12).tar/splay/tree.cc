#include <cstdlib>
#include <new>
#include "tree.h"

/*************************
 * EEE2020: Assignment 6 *
 *************************/

// Destructor
tree_t::~tree_t(void) {
    /* Assignment */
    /* Assignment */
    //we make destructor by using clear function and delete root
    clear();
    delete root;
}

// Get the number of nodes in the tree.
size_t tree_t::size(void) const {
    /* Assignment */
    //size function only returns num elements
    return num_elements;           // Correct this.
}

// Get the tree height.
int tree_t::height(void) const {
    /* Assignment */
    //root will go to height recursive function
    return height(root);           // Correct this.
}
//height() nedds to check the depth of all leaves: O(N)
//This can be done by writing a function that recursively checks
//Protected function gets the height of subtree
//the height of subtrees
int tree_t::height(node_t *m_node) const {
//if root node is 0, return -1
    if(!m_node) { return -1; }
    //Height of left subtree
    int left_height = height(m_node->left);
    //Height of right subtree
    int right_height = height(m_node->right);
    //Take taller height + 1
    return (left_height > right_height ? left_height : right_height) + 1;
}
// Get the minimum element in the tree.
const data_t& tree_t::find_min(void) const {
    /* Assignment */
    //root will go to find_min recursive function
    return find_min(root);  // Correct this.
}
//Finding min
const data_t& tree_t::find_min(node_t *m_node) const {
	node_t *node = m_node;
	//go to left node until there's node left
	while(node->left) { node = node->left;}
	//return last left node's data
	return node->data;
	
}
// Get the maximum element in the tree.
const data_t& tree_t::find_max(void) const {
    /* Assignment */
    //root will go to find_max recursive function
    return find_max(root);  // Correct this.
}
//Finding max
const data_t& tree_t::find_max(node_t *m_node) const {
    node_t *node = m_node;
    //go to right node until there's node right
    while(node->right) { node = node->right;}
    //return last right node's data
    return node->data;
 }
// Remove all nodes inn the tree.
void tree_t::clear(void) {
    /* Assignment */
    //root will go to clear recursive function
    clear(root);
    //we set root 0 : this is version of constructor
    root=0;
    num_elements = 0;
}
//we make clear recursive version
void tree_t::clear(node_t *m_node) {
    //if m_node has left, clear(m_node->left)    
    if(m_node->left){ clear(m_node->left); }
    //if m_node has right, clear(m_node->right) 
    if(m_node->right){ clear(m_node->right); }
    //minus num elements
    num_elements--;
    //delete m_node
    delete  m_node;
    
    }
/*********************
 * End of Assignment *
 *********************/





// Constructor
tree_t::tree_t(void) :
    num_elements(0),
    root(0) {
    // Nothing to do
}

#ifdef DEBUG
#include <iostream>
void tree_t::print(void) const { print(root); }

void tree_t::print(const node_t *m_node, const int m_depth) const {
    if(!m_node) { return; }
    print(m_node->right, m_depth+1);
    if(m_node->left && !m_node->right)  { std::cout << std::endl; }
    for(int d = 0; d < m_depth; d++) { std::cout << "      ";  }
    std::cout << "..."; std::cout << m_node->data << std::endl;
    print(m_node->left,  m_depth+1);
    if(!m_node->left && m_node->right)  { std::cout << std::endl; }
}
#endif

