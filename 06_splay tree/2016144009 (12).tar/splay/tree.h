#ifndef __TREE_H__
#define __TREE_H__

#include <cstdlib>
#include "node.h"

// Binary tree base class
class tree_t {
public:
    tree_t(void);
    virtual ~tree_t(void);

    // Get the number of nodes in the tree.
    size_t size(void) const;
    // Get the tree height.
    int height(void) const;
    // Get the minimum element in the tree.
    const data_t& find_min(void) const;
    // Get the maximum element in the tree.
    const data_t& find_max(void) const;
    // Return true if the tree contains the data.
    virtual bool contains(const data_t &m_data) = 0;
    // Add a new element to the tree.
    virtual void insert(const data_t &m_data) = 0;
    // Remove the element in the tree if it has one.
    virtual void remove(const data_t &m_data) = 0;
    // Remove all nodes in the tree.
    void clear(void);
#ifdef DEBUG
    // Print node data in preorder.
    virtual void print(void) const;
#endif

private:
#ifdef DEBUG
    void print(const node_t *m_node, const int m_depth = 0) const;
#endif

/*************************
 * EEE2020: Assignment 6 *
 *************************/
    void clear(node_t *m_node); //Remove all nodes in the subtree
protected:
    size_t num_elements;    // Number of elements in the tree
    node_t *root;           // Pointer to the root node
    
    int height(node_t *m_node) const; //Get the height of subtree
    const data_t& find_min(node_t *m_node) const; //Get the minimum element in the subtree
    const data_t& find_max(node_t *m_node) const; //Get the maximum element in the subtree
/*********************
 * End of Assignment *
 *********************/
};

#endif

