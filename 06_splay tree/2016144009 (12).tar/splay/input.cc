#include <cstdlib>
#include <iostream>
#include <fstream>
#include <new>
#include "input.h"

// Read an input file.
void input_t::read(const std::string m_file_name) {
    // Open the file.
    std::fstream file_stream;
    file_stream.open(m_file_name.c_str(), std::fstream::in|std::fstream::binary);
    if(!file_stream.is_open()) {
        std::cerr << "Error: failed to open " << m_file_name << std::endl;
        exit(1);
    }
    delete [] array;
    // Get the number of data points.
    if(!file_stream.read((char*)&array_size, sizeof(data_t))) {
        std::cerr << "Error: failed to read " << m_file_name << std::endl;
        file_stream.close();
        exit(1);
    }
    // Load the data points into the array.
    array = new data_t[array_size];
    if(!file_stream.read((char*)array, array_size * sizeof(data_t))) {
        std::cerr << "Error: failed to read " << m_file_name << std::endl;
        delete [] array;
        file_stream.close();
        exit(1);
    }
    // Close the file.
    file_stream.close();
}    

