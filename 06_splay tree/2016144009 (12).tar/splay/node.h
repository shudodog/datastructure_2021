#ifndef __NODE_H__
#define __NODE_H__

#include "data.h"

class node_t {
public:
    // Node constructors
    node_t(void) : left(0), right(0) { }
    node_t(const data_t &m_data) : left(0), right(0), data(m_data) { }

    node_t *left, *right;       // Pointers to left and right children
    data_t data;                // Node data;
};

#endif

