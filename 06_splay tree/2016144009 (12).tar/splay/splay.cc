#include <cstdlib>
#include <new>
#include "splay.h"

/*************************
 * EEE2020: Assignment 6 *
 *************************/
node_t* splay_t::rotate_with_left(node_t *m_node) {
    node_t *left = m_node->left;
    m_node->left = left->right; //Right child of left child becomes the left child of m_node
    left->right = m_node; //m_node becomes the right child of left child
    return left; //Left child becomes the root of subtree
    }

node_t* splay_t::rotate_with_right(node_t *m_node) {
    node_t *right = m_node->right;
    m_node->right = right->left; //left child of right child becomes the right child of m_node
    right->left = m_node; //m_node becomes the left child of right child
    return right; //Right child becomes the root of subtree
    }
    
// Return true if the tree contains the data.
bool splay_t::contains(const data_t &m_data) {
    /* Assignment */
    root = splay(m_data, root);      // Splay the tree.
    return m_data == root->data;      // The root has the element, if the tree had it
}

//Splay the subtree.
node_t* splay_t::splay(const data_t &m_data, node_t *m_node) {

    if(m_node){ //Nothing to splay for the void subtree
       if((m_data < m_node->data) && (m_node->left)) {//Zig nodes
          if(m_data < m_node->left->data){ //Zig-zig nodes
              m_node->left->left = splay(m_data, m_node->left->left); //Splay the subtree
              m_node = rotate_with_left(m_node); //Single rotation with the left child
           }
          else if(m_node->left->data < m_data ){ // Zig-Zag nodes
          
              //First splay(m_data, m_node->left->right) and m_node->left->right becomes it
              m_node->left->right = splay(m_data, m_node->left->right);
              //Do right rotation for root->left
              if (m_node->left->right){
                  m_node->left = rotate_with_right(m_node->left); 
                  
                  }
                  
                 }            
          return m_node->left ? rotate_with_left(m_node) : m_node; //Another single rotation if necessary
        }
        
        else if((m_node->data < m_data) && (m_node->right)) { //Zag nodes
        
           if(m_data < m_node->right->data){ //m_data is smaller than m_node's right child of data
           //m_node's right child of left becomes splay(m_data, m_node's right child of left child)
           m_node->right->left = splay(m_data, m_node->right->left);
                
                //if m_node's right child of left child exists
                if(m_node->right->left){
               //m_node's right child becomes rotate with left of m_node's right child
                    m_node->right = rotate_with_left(m_node->right);
                    }
            }
            
            else if(m_node->right->data < m_data) {//Zag-zag(right right)
                //m_node's right child of right child becomes splay(m_data, m_node's right child of right child
                m_node->right->right = splay(m_data, m_node->right->right);
                //m_node becomes rotate with right of m_node
                m_node = rotate_with_right(m_node);
                }
                //Do second rotation for root if neccesary
                
            return m_node->right ? rotate_with_right(m_node) : m_node;
                    
                
        }
    }
    
    return m_node; 
    
}
// Add a new element to the tree.
void splay_t::insert(const data_t &m_data) {
    /* Assignment */
    //Empty tree simply adds a new node at the root.
    if(!root) { root = new node_t(m_data); num_elements++; return; }
    //Splay the tree against m_data.
    root = splay(m_data, root);
    if(root->data < m_data) {
    	//Create a new node containing m_data.
    	node_t *node = new node_t(m_data);
    	//update num_elements
    	num_elements++;
    	//Since the element of current root is smaller, it becomes the left of new node.
    	node->left = root;
    	//node's right child becomes root's right child
    	node->right = root->right;
    	//make root's right child 0
    	root->right = 0;
    	// node becomes the root
    	root = node;
    	}
    else if(m_data < root->data) {
    //If root's data is biggerr, make root to right child of newnode and copy root's left child to a new node
        node_t *node = new node_t(m_data);
        num_elements++;
        node->right = root;
        node->left = root->left;
        root->left = 0;
        root = node;
    }
    //Otherwise, the root already contains m_data. Nothing to do
}


// Remove the element in the tree if it has one.
void splay_t::remove(const data_t &m_data) {
    /* Assignment */
    
    
    //If left child of root does not exist make root->right as root
    if(root){
    //Splay the root
    
    root = splay(m_data, root);
    
    if(m_data == root->data){
    
    
    
    if(!root->left)
    {
       //left child of root does not exist make root's right child as root
    	node_t *m_node = root;
    	root = m_node->right;
    	//delete m_node
    	delete m_node;
    	}
    	
   else{
    	//if left child exist
    	//m_node is root and splay(m_data, root->left) into root
    	//we make root's right child to m_node's right child
    	//delete m_node
    	node_t *m_node = root;
    	root = splay(m_data, root->left);
    	root->right = m_node->right;
    	delete m_node;
    	
    	}
    //update num_elements
    num_elements--;
    }
    	
    	}
}

/*********************
 * End of Assignment *
 *********************/





// Constructor
splay_t::splay_t(void) { /* Nothing to do */ }

// Destructor
splay_t::~splay_t(void) { /* Nothing to do */ }

