#ifndef __INPUT_H__
#define __INPUT_H__

#include <fstream>
#include <iostream>
#include <string>
#include "data.h"

// Input handler
class input_t {
public:
    input_t(std::string m_file_name = "input") : array(0), array_size(0) { read(m_file_name); }
    ~input_t() { delete [] array; }

    size_t size() const { return array_size; }
    data_t* get_array() const { return array; }
    data_t& operator[](const size_t m_index) const { return array[m_index]; }

private:
    // Read an input file.
    void read(const std::string m_file_name) {
        // Open the file.
        std::fstream file_stream;
        file_stream.open(m_file_name.c_str(), std::fstream::in|std::fstream::binary);
        if(!file_stream.is_open()) {
            std::cerr << "Error: failed to open " << m_file_name << std::endl;
            exit(1);
        }
        delete [] array;
        // Get the number of data points.
        if(!file_stream.read((char*)&array_size, sizeof(data_t))) {
            std::cerr << "Error: failed to read " << m_file_name << std::endl;
            file_stream.close();
            exit(1);
        }
        // Load the data points into the array.
        array = new data_t[array_size];
        if(!file_stream.read((char*)array, array_size * sizeof(data_t))) {
            std::cerr << "Error: failed to read " << m_file_name << std::endl;
            delete [] array;
            file_stream.close();
            exit(1);
        }
        // Close the file.
        file_stream.close();
    }

    data_t *array;
    size_t array_size;
};

#endif

