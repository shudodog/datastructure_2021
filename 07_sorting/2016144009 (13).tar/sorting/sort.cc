#include "sort.h"


// Heap sort
void heapsort(data_t* array, const size_t size) {
    /* Assignment */
    //make heap
    //we start i= 1 while i is smaller than size
    for(size_t i = 1; i < size; ++i){
    //we make child same as i
    size_t child = i;
    //we make do~while child is not zero
    do{
    	//make root as half of child-1
    	size_t root = (child-1)/2 ;
    	//if array[root] is smaller than array[child] swap array[root] and array[child]
    	if(array[root] < array[child]){
    		//make temp same as array[root]
    		size_t temp = array[root];
    		//make array[root] same as array[child]
    		array[root] = array[child];
    		//make array[child] same as temp(before array[root]
    		array[child] = temp;
    		}
    	//make child same as root
    	child = root;
    }while(child!=0);
    }
    
    //Repeated heap configuration with reduced size
    //start i same as size -1 and do while i>0
    for(size_t i = size - 1; i > 0; i--) {
    //swap array[0]and array[i]
    size_t temp = array[0];
    array[0] = array[i];
    array[i] = temp;
     
    //initialize root as 0 and child as 1
    size_t root = 0;
    size_t child = 1;
    //do whild child is smaller than i
    do{
    	//make child as multiply root and 2 and plus 1
    	child = 2*root + 1;
    	//if child is smaller than i minus 1 and array[child] is smalller than array[child+1] , we make child +1
    	if(child < i - 1 && array[child] < array[child + 1]){
    	child++;
    	}
    	//if child is smaller than i and array[root] is smaller than array[child] we swap array[root] and array[child]
    	if(child < i && array[root] < array[child]) {
    		temp = array[root];
    		array[root] = array[child];
    		array[child] = temp;
    		}
    		root = child;
    		}while(child<i);
    }
    }

