#ifndef __SORT_H__
#define __SORT_H__

#include <cstdlib>
#include "data.h"

// Heap sort
void heapsort (data_t* array, const size_t size);

// Is the array sorted?
template <typename T1, typename T2>
bool is_sorted(T1* array, const T2 size) {
    for(T1 *ptr = array; ptr < array + size - 1; ptr++) {
        if(*ptr > *(ptr + 1)) { return false; }
    }
    return true;
}

#endif

