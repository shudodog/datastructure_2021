#include <string>
#include "input.h"
#include "sort.h"

int main(int argc, char **argv) {
    // Function pointer to heapsort
    void (*sort)(data_t*, const size_t) = &heapsort;
    // Data array and size
    data_t *array = 0;
    size_t array_size = 0;





    /**************************************
     * TEST YOUR CODE HERE FOR VALIDATION *
     **************************************/

    // Allocate a small test array.
    array_size = 20;
    array = new data_t[array_size];


    // Generate random integers between 0 and 99.
    std::cout << "array = [ ";
    for(size_t i = 0; i < array_size; i++) {
        array[i] = rand() % 100;
        std::cout << array[i] << " ";
    }   std::cout << "]" << std::endl;


    // Sort the numbers.
    sort(array, array_size);


    // Print the array elements.
    std::cout << "array = [ ";
    for(size_t i = 0; i < array_size; i++) {
        std::cout << array[i] << " ";
    }   std::cout << "]" << std::endl;


    // Deallocate the array.
    delete [] array;

    /******************
     * END OF TESTING *   
     ******************/





    /* *************************************************
     * WARNING: DO NOT MODIFY THE CODE BELOW THIS LINE *
     ***************************************************/

    // Proceed?
    if(argc != 2) { return 0; }

    // Load numbers from an input file.
    input_t input(argv[1]);
    array = input.get_array();
    array_size = input.size();

    std::cout << std::endl << "Sorting " << array_size << " numbers: ";

    // Sort the numbers.
    sort(array, array_size);

    // Check if the array is sorted.
    std::cout << "Array is " << (is_sorted(array, array_size) ? "" : "NOT ")
              << "sorted "   << std::endl;

    return 0;
}

