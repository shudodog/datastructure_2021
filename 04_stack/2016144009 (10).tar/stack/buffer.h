#ifndef __BUFFER_H__
#define __BUFFER_H__

#include "stack.h"

namespace ds {

// buffer_t is a derived class of stack_t.
class buffer_t : public stack_t {
public:
    // Get the reference of element at the specified index.
    data_t& operator[](const size_t m_index) const { return array[m_index]; }    
};

}; // End of namespace ds

#endif

