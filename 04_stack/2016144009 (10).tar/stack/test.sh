#!/bin/bash

# Infix expressions
expression=("51 - 3 * 8 + 20"
            "3 - 4.2 * 7 - 10 + 5 / -2 + 12.3 * 3"
            "-7 / (-3 + 1) + -2 * 9 - (0.5 + 3) * 5"
            "17 - 5 * (-3 - 1.5 * 4) / (2 + 2.5 / 5) - 5 * 3"
            "(15.7 - (3 - 2) * 5 / 2) + 5 * 2.2 / (5.1 - 2.6) * 2 - (-5 * 3.1)"
            "(((11 / 2) - 5) * (2 + ((4 - 1.5) / -2.5 * 5) * -1)) - (5.25 - 2.5 * 2.5)"
           )

# Build the code.
make clean > /dev/null; make -j > /dev/null

# Test runs
r=0;
for x in "${expression[@]}"; do
    echo "Test #$((++r)):"; ./postfix "$x"; echo ""
done

