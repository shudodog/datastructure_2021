#include <cstdlib>
#include <iostream>
#include <new>
#include "stack.h"

namespace ds {

#define STACK_SIZE 1024

// Constructor
stack_t::stack_t(void) :
    array(0),
    array_size(STACK_SIZE),
    num_elements(0) {
    // Reserve a memory space.
    array = (data_t*)malloc(sizeof(data_t) * array_size);
}

// Destructor
stack_t::~stack_t() {
    // Destruct all data, and deallocate the array.
    for(size_t i = 0; i < num_elements; i++) { array[i].~data_t(); }
    free(array);
}

// Get the number of elements in the stack.
size_t stack_t::size(void) const { return num_elements; }

// Return true if the stack has no elements.
bool stack_t::empty(void) const { return !num_elements; }

// Get a reference of the top element.
data_t& stack_t::top(void) const { return array[num_elements-1]; }





/*************************
 * EEE2020: Assignment 4 *
 *************************/

// Push back a new element to the stack.
void stack_t::push(const data_t &m_data) {
    /* Assignment */
    //Call a copy constructor at the end of the array
    new (&array[num_elements++]) data_t(m_data);
    
    
}

// Pop back the last element of stack.
void stack_t::pop(void) {
    /* Assignment */
    //removes the last element in the array
    if(num_elements){ array[--num_elements].~data_t(); }
}

/*********************
 * End of Assignment *
 *********************/





}; // End of namespace ds

