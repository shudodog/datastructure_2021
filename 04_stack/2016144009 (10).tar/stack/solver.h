#ifndef __SOLVER_H__
#define __SOLVER_H__

#include <string>
#include "buffer.h"
#include "stack.h"

namespace ds {

#define numbers   std::string(".0123456789")
#define operators std::string("+-*/")
#define parens    std::string("()")

#define is_positive_number(s) \
    (s.find_first_not_of(numbers) == std::string::npos)
#define is_negative_number(s) \
    ((s.size() > 1) && (s[0] == '-') && (s.find_first_not_of(numbers, 1) == std::string::npos))
#define is_number(s) \
    (is_positive_number(s) || is_negative_number(s))
#define is_float(s) \
    (s.find_first_not_of(".") != std::string::npos)
#define is_operator(s) \
    (operators.find(s) != std::string::npos)
#define is_paren(s) \
    (parens.find(s) != std::string::npos)
#define string_to_float(s) \
    std::stof(s)
#define float_to_string(f) \
    std::to_string(f)

class solver_t {
public:
    // Solve the expression.
    std::string solve(const std::string &expression);

private:
    // Convert the infix expression to postfix.
    void convert_infix_to_postfix(void);
    // Calculate the postfix expression.
    void calculate_postfix(void);
    // Parse the string expression.
    void parse(const std::string &expression);

    buffer_t infix_buffer;      // Infix buffer
    buffer_t postfix_buffer;    // Postfix buffer
    stack_t  operator_stack;    // Operator stack
    stack_t  number_stack;      // Number stack
};

}; // End of namespace ds

#endif
