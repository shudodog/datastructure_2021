#include <cstring>
#include <iostream>
#include "solver.h"

namespace ds {

/*************************
 * EEE2020: Assignment 4 *
 *************************/

// Convert infix expression to postfix.
void solver_t::convert_infix_to_postfix(void) {
    /* Assignment */
    
    //we use soso to know whether "(" is in or not, default value is 0
    size_t soso = 0;
    for(size_t i = 0; i < infix_buffer.size(); i++){
    //we define term as infix_buffer[i]
    	std::string &term = infix_buffer[i];
    	//if term is "(", we push term in operator stack and plus soso
    	if(term == "("){
    		operator_stack.push(term);
    		soso++;
    		
    		}
    	//if term is ")", we push operator_stack' top in postfix buffer and pop operator stack while operatoar stack'top is not "("
    	else if(term == ")"){
    		while(operator_stack.top() != "("){
    			postfix_buffer.push(operator_stack.top());
    			operator_stack.pop();
    			}
    		//if operator stack's top is "(", we pop opearater stack and minus soso
    		if(operator_stack.top() == "("){operator_stack.pop();}
    		soso --;
    		// if operator stack'top is "*" or "/", we push operator stack'top into postfix buffer and pop that operator stack.
    		if(operator_stack.top() == "*" || operator_stack.top() == "/"){
    			postfix_buffer.push(operator_stack.top());
    			operator_stack.pop();
    		}
    		}
    	// if term is not "+", "-". "*" or "/", we push term into postfix buffer
    	else if(term != "+" && term != "-" && term != "*" && term != "/" ){
    		postfix_buffer.push(term);
    		//if operator stack'top is "*" or "/", we push operator stack'top into postfix buffer and pop operator stack
    		if(operator_stack.top() == "*"||operator_stack.top() == "/"){
    			postfix_buffer.push(operator_stack.top());
    			operator_stack.pop();
    			}
    			
    		}
    	//if soso is not zero( it means there is "(" ) we push term into operator stack
    	else if(soso != 0){
    		operator_stack.push(term);
    	}
    	//if term is "+" or "-", we push operator stack'top into postfix buffer and pop operator stack while stack is not empty, after that we push term to operator stack	
    	else if(term == "+" || term == "-"){
    		while(!operator_stack.empty()){
    			postfix_buffer.push(operator_stack.top());
    			operator_stack.pop();
    			}
    		operator_stack.push(term);
    		}
    	//push term to operator stack 
    	else{
    		operator_stack.push(term);
    		}
    }
    // we push stack'top to postfix buffer and pop operator stack while operator stack is not empty
    while(!operator_stack.empty()){
    	postfix_buffer.push(operator_stack.top());
    	operator_stack.pop();
    	}
    
    
    	
    			
}

// Calculate the postfix expression.
void solver_t::calculate_postfix(void) {
    /* Assignment */
    
    for(size_t i = 0; i < postfix_buffer.size(); i++){
    // term is postfix buffer
    	std::string &term = postfix_buffer[i];
    	// if term is is number we push term into number stack
    	if(is_number(term)){ number_stack.push(term);}
    	//else we change number stack'top to type float and pop number stack
    	else{
    		float operand2 = string_to_float(number_stack.top());
    		number_stack.pop();
    		float operand1 = string_to_float(number_stack.top());
    		number_stack.pop();
    		float result;
    		//if term is "+" result is operan1 plus operand2
    		if (term == "+"){ result = operand1 + operand2;}
    		//if term is "-" result is operand1 minus operand2
    		else if (term == "-"){result = operand1 - operand2;}
    		//if term is "*" result is operand1 multiply operand2
    		else if (term == "*"){result = operand1*operand2;}
    		//if term is "/" result is operand divide operand2
    		else if (term == "/"){result = operand1/operand2;}
    		//change result to string and push result into number stack
    		number_stack.push(float_to_string(result));
    		}
    	}
    
}

/*********************
 * End of Assignment *
 *********************/





// Solve the expression.
std::string solver_t::solve(const std::string &expression) {
    // Parse the string expression.
    parse(expression);

    // Show the infix expression.
    std::cout << "infix expression:";
    for(size_t i = 0; i < infix_buffer.size(); i++) { std::cout << " " << infix_buffer[i]; }
    std::cout << std::endl;

    // Convert the infix expression to postfix.
    convert_infix_to_postfix();

    // Show the postfix expression.
    std::cout << "postfix expression:";
    for(size_t i = 0; i < postfix_buffer.size(); i++) { std::cout << " " << postfix_buffer[i]; }
    std::cout << std::endl;

    // Calculate the postfix expression.
    calculate_postfix();

    // Return the final result left in the operator stack.
    return number_stack.top();
}

// Parse the string expression.
void solver_t::parse(const std::string &expression) {
    try {
        // Check if the expression has illegal characters.
        size_t e = expression.find_first_not_of(numbers+operators+parens+" ");
        if(e != std::string::npos) { throw "invalid characters"; }
    
        // Parse the expression into operators and numbers.
        for(e = 0; e < expression.size(); ) {
            if(expression[e] == ' ') { e++; continue; }         // Skip spaces
            if((expression.find_first_of("()*/+", e) == e) ||   // "()*/+" operators
              ((expression[e] == '-') && infix_buffer.size() && // "-" operator
              ((infix_buffer.top() == ")") || (is_number(infix_buffer.top()))))) {
                infix_buffer.push(std::string(1, expression[e++]));
            }
            else {                                              // Numbers
                size_t p = expression.find_first_not_of(numbers, expression[e] == '-' ? e+1 : e);
                size_t l = (p == std::string::npos ? expression.size() : p) - e;
                infix_buffer.push(expression.substr(e, l)); e += l;
            }
        }

        if(!infix_buffer.size()) { throw "empty infix buffer"; }
   
        // Sanity check 
        if(is_operator(infix_buffer[0]) || is_operator(infix_buffer.top())) {
            throw "dangling operator";            // Expr begins or ends with operator.
        }
        if((infix_buffer[0] == ")") || (infix_buffer.top() == "(")) {
            throw "dangling parenthesis";         // Expr begins w/ ')' or ends w/ '('.
        }
        unsigned num_parens = is_paren(infix_buffer[0]);
        for(e = 1; e < infix_buffer.size(); e++) {
            if(is_operator(infix_buffer[e]) &&
               ((infix_buffer[e-1] == "(") || is_operator(infix_buffer[e-1]))) {
                throw "dangling operator";        // Operator after '(' or another operator
            }
            else if(infix_buffer[e] == "(") {
                num_parens++;
                if(is_number(infix_buffer[e-1]) || (infix_buffer[e-1] == ")")) {
                    throw "dangling parenthesis"; // '(' after number number or ')'
                }
            }
            else if(infix_buffer[e] == ")") {
                num_parens--;
                if(is_operator(infix_buffer[e-1]) || (infix_buffer[e-1] == "(")) {
                    throw "dangling parenthesis"; // ')' after operator or '('
                }
            }
            else if(is_number(infix_buffer[e])) {
                if(is_number(infix_buffer[e-1]) || (infix_buffer[e-1] == ")")) {
                    throw "dangling number";      // number after number or ')'
                }
                if(is_float(infix_buffer[e]) && ((infix_buffer[e][0] == '.') ||
                   (infix_buffer[e][infix_buffer[e].size()-1] == '.') ||
                   (infix_buffer[e].find_first_of(".",
                    infix_buffer[e].find_first_of(".")+1) != std::string::npos))) {
                    throw "invalid floating-point number";
                }
            }
        }
        if(num_parens) { throw "mismatched parens"; }
    }
    catch (const char *msg) {
        std::cerr << "Error: " << msg << ": " << expression << std::endl; exit(1);
    }
}

}; // End of namespace ds

