#ifndef __STACK_H__
#define __STACK_H__

#include "data.h"

namespace ds {

class stack_t {
public:
    stack_t(void);          // Constructor
    virtual ~stack_t(void); // Destructor

    // Get the number of elements in the stack.
    size_t size(void) const;
    // Return true if the stack has no elements.
    bool empty(void) const;
    // Get a reference of the top element.
    data_t& top(void) const;
    // Push back a new element to the stack.
    void push(const data_t &m_data);
    // Pop back the last element of stack.
    void pop(void);

protected:
    data_t *array;          // Pointer to an array used as a stack
    size_t array_size;      // Allocated array size
    size_t num_elements;    // Number of elements in the array
};

}; // End of namespace ds

#endif

