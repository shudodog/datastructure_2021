#include <iostream>
#include "solver.h"

int main(int argc, char **argv) {
    // Run command message
    if(argc != 2) {
        std::cerr << "Usage: " << argv[0] << " 'expression'" << std::endl; exit(1);
    }
    
    /*
    //Test code to validate stack implementation
    ds::stack_t st;
    st.push("1");
    st.push("+");
    st.push("2");
    std::cout << st.top()  << std::endl;
    std::cout << st.size() << std::endl;
    st.pop();
    std::cout << st.top()  << std::endl;
    std::cout << st.size() << std::endl;
    st.pop();
    std::cout << st.top()  << std::endl;
    std::cout << st.size() << std::endl;
    */

    // Solve the expression.
    ds::solver_t solver;
    std::string result = solver.solve(argv[1]);
    std::cout << "result = " << std::stof(result) << std::endl;

    return 0;
}

